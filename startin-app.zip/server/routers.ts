import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  // Contrato inicial: substituir o mock de Home.tsx por esta procedure
  // quando a tabela de oportunidades estiver disponível no banco.
  opportunities: router({
    list: publicProcedure.query(() => ({
      items: [],
      nextCursor: null as string | null,
    })),
  }),
});

export type AppRouter = typeof appRouter;
